//
// Created by namlu on 29/11/2024.
//

#ifndef MEREA_H
#define MEREA_H
#include <iostream>



class MereA {
public:
    void display() const {
        std::cout << "Message de la classe mère A." << std::endl;
    }
};




#endif //MEREA_H
