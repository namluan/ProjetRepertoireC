//
// Created by namlu on 15/11/2024.
//

#ifndef SOMME_H
#define SOMME_H


//EXO 9
class Somme {
public:
    float n1;
    float n2;
    float Sum();
};



#endif //SOMME_H
