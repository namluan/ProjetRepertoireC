//
// Created by namlu on 15/11/2024.
//

#ifndef RECTANGLE_H
#define RECTANGLE_H


//EXO 8
class Rectangle {
public:
    float a;
    float b;
    float surface();
};



#endif //RECTANGLE_H
