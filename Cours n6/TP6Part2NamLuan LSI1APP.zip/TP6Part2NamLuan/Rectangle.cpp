//
// Created by namlu on 15/11/2024.
//


#include "Rectangle.h"
#include <iostream>
#include <ostream>
using namespace std;

//EXO 8
float Rectangle::surface() {
    return a*b;
}