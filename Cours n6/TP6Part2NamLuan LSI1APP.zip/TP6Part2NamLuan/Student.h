//
// Created by namlu on 15/11/2024.
//

#ifndef STUDENT_H
#define STUDENT_H



class Student {
public:
    char nom[50];
    int note1, note2;
    float calc_moy();
    void show();
};



#endif //STUDENT_H
