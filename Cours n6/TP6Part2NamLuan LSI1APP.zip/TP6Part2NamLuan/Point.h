//
// Created by namlu on 15/11/2024.
//

#ifndef POINT_H
#define POINT_H



class Point {
private:
    int x,y;
public:
    Point(int x, int y);

    double distance(Point p);



};



#endif //POINT_H
