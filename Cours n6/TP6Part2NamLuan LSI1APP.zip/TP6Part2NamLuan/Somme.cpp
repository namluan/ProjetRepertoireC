//
// Created by namlu on 15/11/2024.
//

#include "Somme.h"

//EXO 9
float Somme::Sum() {
    return n1+n2;
}
